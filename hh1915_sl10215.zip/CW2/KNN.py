from scipy.io import loadmat
from scipy.spatial import distance
from sklearn.cluster import KMeans
from timeit import default_timer as timer
from scipy import stats
import json
import numpy as np



def KNN(test_img, gallery,k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(gallery))
    idx_arr = np.zeros(len(gallery))
    results = np.zeros(k)
    for i in range(len(gallery)):
        if (gallery[i] != 0):
            pi = features_arr[gallery[i]]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent
        else:
            d_arr[i] = float('inf')

    tmparr = np.argsort(d_arr)
    
    for n in range (len(gallery)):
       idx_arr[n] = gallery[tmparr[n]] 
    
    for j in range (k):
        results[j] = idx_arr[j]
        
    return results


def KNN_KMean(test_img, center_features, center_classes, k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(center_features))
    idx_arr = np.zeros(len(center_features))
    result_classes = np.zeros(k)
    for i in range(len(center_features)):
            pi = center_features[i]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent

    tmparr = np.argsort(d_arr)
    
    for n in range (len(center_features)):
       idx_arr[n] = center_classes[tmparr[n]] 
    
    for j in range (k):
        result_classes[j] = idx_arr[j]
        
    return result_classes


######################################################################################################
K = 10 #number of nearest neighbours
starttime = timer()

file = loadmat('cuhk03_new_protocol_config_labeled.mat')
with open('feature_data.json', 'r') as f:
    features = json.load(f)
features_arr = np.array(features)
camId = file['camId'] 
filelist = file['filelist'] 
gallery_idx = file['gallery_idx']
labels = file['labels'] 
query_idx = file['query_idx'] 
train_idx = file['train_idx']    
results = np.zeros(K)
accuracy_arr = np.zeros(len(query_idx))
accuracy_Km_arr = np.zeros(len(query_idx))

gallery_idx = gallery_idx - 1;
query_idx = query_idx - 1;
train_idx = train_idx - 1;
camId = camId - 1;


for i in range (len(query_idx)):
    print ('query_idx = ',i)        
    classified = False
    tmpgallery = gallery_idx.copy()
    label_q = labels[query_idx[i]]
    camId_q = camId[query_idx[i]]
    for j in range (len(gallery_idx)):
        if ((labels[gallery_idx[j]] == label_q) and (camId[gallery_idx[j]] == camId_q)):
            tmpgallery[j] = 0
            
    results = KNN(query_idx[i], tmpgallery, K)
    for c in range (K):
        if (labels[int(results[c])] == label_q):
            accuracy_arr[i] = 1
accuracy = (np.count_nonzero(accuracy_arr))/len(accuracy_arr)    
print ("accuracy is ", accuracy)





         