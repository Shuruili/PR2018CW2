from scipy.io import loadmat
from scipy.spatial import distance
from sklearn.cluster import KMeans
from timeit import default_timer as timer
from scipy import stats
from metric_learn import Covariance
from metric_learn import LMNN
from metric_learn import MMC_Supervised

import random
import json
import numpy as np



def KNN(test_img, gallery,k):
    pa = features_pca[test_img]
    d_arr = np.zeros(len(gallery))
    idx_arr = np.zeros(len(gallery))
    results = np.zeros(k)
    for i in range(len(gallery)):
        if (gallery[i] != 0):
            pi = features_pca[gallery[i]]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent
        else:
            d_arr[i] = float('inf')

    tmparr = np.argsort(d_arr)
    
    for n in range (len(gallery)):
       idx_arr[n] = gallery[tmparr[n]] 
    
    for j in range (k):
        results[j] = idx_arr[j]
        
    return results


def KNN_KMean(test_img, center_features, center_classes, k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(center_features))
    idx_arr = np.zeros(len(center_features))
    result_classes = np.zeros(k)
    for i in range(len(center_features)):
            pi = center_features[i]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent

    tmparr = np.argsort(d_arr)
    
    for n in range (len(center_features)):
       idx_arr[n] = center_classes[tmparr[n]] 
    
    for j in range (k):
        result_classes[j] = idx_arr[j]
        
    return result_classes


def KNN_cov_metric(test_img, gallery,k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(gallery))
    idx_arr = np.zeros(len(gallery))
    results = np.zeros(k)
    for i in range(len(gallery)):
        if (gallery[i] != 0):
            pi = features_arr[gallery[i]]
            dcurrent = np.matmul( np.matmul((pa-pi),M),(pa-pi).T )
            d_arr[i] = dcurrent

        else:
            d_arr[i] = float('inf')
    tmparr = np.argsort(d_arr)    
    for n in range (len(gallery)):
       idx_arr[n] = gallery[tmparr[n]]     
    for j in range (k):
        results[j] = idx_arr[j]        
    return results



def PCA(trainingset):
    (D,N) = np.shape(trainingset)
    A = np.zeros((D,N))
    eigenval_low_sort = np.zeros((N,1), dtype=np.complex)
    eigenvecs_low_sort = np.zeros((D,N), dtype=np.complex)
    meanFace = np.sum(trainingset, axis=1)/N

    for n in range(N):          
                A[:,n] = trainingset[:,n] - meanFace

    S_low = np.matmul(A.transpose(),A)/(N)
    eigvals_low, eigvecs_low_v = np.linalg.eig(S_low)
    eigvecs_low = np.matmul(A,eigvecs_low_v)
    eigvals_low_index = np.argsort(-eigvals_low, axis=-1, kind='quicksort', order=None)
       
    for i in range(N):
        eigenval_low_sort[i] = eigvals_low[eigvals_low_index[i]]
        
    for i in range(N):
        eigenvecs_low_sort[:,i] = eigvecs_low[:,eigvals_low_index[i]]
        eigenvecs_low_sort[:,i] = eigenvecs_low_sort[:,i]/np.linalg.norm(eigenvecs_low_sort[:,i])
    eigsum = sum(eigvals_low)
    csum = 0;
    for i in range(N):
        csum = csum + eigenval_low_sort[i]
        percentage = csum/eigsum
        if percentage > 0.99:
            M = i
            break
    return(eigenvecs_low_sort,M,meanFace)



############################# read data  ##############################################
print ('Reading data...')

K = 1 #number of nearest neighbours
starttime = timer()
file = loadmat('cuhk03_new_protocol_config_labeled.mat')
with open('feature_data.json', 'r') as f:
    features = json.load(f)
features_arr = np.array(features)
camId = file['camId'] 
filelist = file['filelist'] 
gallery_idx = file['gallery_idx']
labels = file['labels'] 
query_idx = file['query_idx'] 
train_idx = file['train_idx']    
results = np.zeros(K)
accuracy_arr = np.zeros(len(query_idx))
accuracy_Km_arr = np.zeros(len(query_idx))

#converting index from 1-> to 0->
gallery_idx = gallery_idx - 1;
query_idx = query_idx - 1;
train_idx = train_idx - 1;
camId = camId - 1;


#########################   Train Validation split   ##########################
validation_id = np.zeros(100)
validation_arr = np.array([])
idx_set = set()
train_idx_new = np.array([])
vali_query = np.array([])
vali_gallery = np.array([])
for i in range (len(train_idx)):
    identity = np.asscalar(labels[train_idx[i]])
    idx_set.add(identity)
validation_id = random.sample(idx_set,100)
for i in range (len(train_idx)):
    if (labels[train_idx[i]] in validation_id):
        validation_arr = np.append(validation_arr, train_idx[i])
    else:
        train_idx_new = np.append(train_idx_new, train_idx[i])

tmplabel = 0
for i in range (len(validation_arr)):
    if(labels[int(validation_arr[i])] != tmplabel):
        vali_query = np.append(vali_query, validation_arr[i])
        vali_query = np.append(vali_query, validation_arr[i+1])
        tmp = i+1
        tmplabel = labels[int(validation_arr[i])]
    elif(i != tmp):
        vali_gallery = np.append(vali_gallery, validation_arr[i])
train_idx_new = train_idx_new.astype(int)
vali_gallery = vali_gallery.astype(int)
vali_query = vali_query.astype(int)
#############################   ##############################################
train_set = np.zeros((len(train_idx_new),2048))
for i in range (len(train_idx_new)):
    train_set[i] = features_arr[train_idx_new[i]]
train_set = train_set.transpose()  
    
'''
query_set = np.zeros((len(query_idx),2048))
for i in range (len(query_idx)):
    query_set[i] = features_arr[query_idx[i]]
query_set = query_set.transpose()  


gallery_set = np.zeros((len(gallery_idx),2048))
for i in range (len(gallery_idx)):
    gallery_set[i] = features_arr[gallery_idx[i]]    
gallery_set = gallery_set.transpose()  


    
train_label = np.zeros((len(train_idx)))    
for i in range (len(train_idx)):
    train_label[i] = labels[train_idx[i]]
'''    

(eigenvecs,m,mean) = PCA(train_set)
M=500
eigenvecs = eigenvecs[:,0:M]

'''
Aquery = np.zeros((2048,len(query_idx)))
wquery_matrix = np.zeros((M,len(query_idx)))

Agallery = np.zeros((2048,len(gallery_idx)))
wgallery_matrix = np.zeros((M,len(gallery_idx)))

Atrain = np.zeros((2048,len(train_idx)))
wtrain_matrix = np.zeros((M,len(train_idx)))
'''

Afeatures = np.zeros((2048,len(features_arr)))
features_pca = np.zeros((M,14096))
features_arr_copy = features_arr.transpose()
for n in range(len(features_arr)):          
    Afeatures[:,n] = features_arr_copy[:,n] - mean


for i in range(M):
    for n in range(len(features_arr)):
        features_pca[i,n] = np.matmul(np.transpose(Afeatures[:,n]) , eigenvecs[:,i]).real

features_pca = features_pca.transpose()

'''
for n in range(len(query_idx)):          
    Aquery[:,n] = query_set[:,n] - mean
for n in range(len(gallery_idx)):
    Agallery[:,n] = gallery_set[:,n] - mean
for n in range(len(train_idx)):
    Atrain[:,n] = train_set[:,n] - mean


for i in range(M):
    for n in range(len(train_idx)):
        wtrain_matrix[i,n] = np.matmul(np.transpose(Atrain[:,n]) , eigenvecs[:,i]).real    

for i in range(M):
    for n in range(len(query_idx)):
        wquery_matrix[i,n] = np.matmul(np.transpose(Aquery[:,n]) , eigenvecs[:,i]).real 
        
for i in range(M):
    for n in range(len(gallery_idx)):
        wgallery_matrix[i,n] = np.matmul(np.transpose(Agallery[:,n]) , eigenvecs[:,i]).real 
'''




##########################  Mahalanobi distance learning:  #########################
train_set_pca = np.zeros((len(train_idx_new),M))
for i in range (len(train_idx_new)):
    train_set_pca[i] = features_pca[train_idx_new[i]]
    
train_label = np.zeros((len(train_idx_new)))    
for i in range (len(train_idx_new)):
    train_label[i] = labels[train_idx_new[i]]
    
print ('Enter distance metric learning model type')        
    
model = input()
print ('training train set to obtain the distance matrix M...')    
if (model != 'base'):    
    if (model == 'cov'):
        cov = Covariance().fit(train_set_pca)
        features_pca = cov.transform(features_pca)

    if (model == 'lmnn'):
        lmnn = LMNN(k=5, max_iter=100, learn_rate=5e-9, use_pca=False)
        lmnn_metric = lmnn.fit(train_set_pca,train_label)
        features_pca = lmnn_metric.transform(features_pca)

    if (model == 'MMC'):
        mmc = MMC_Supervised(max_iter=10, num_constraints=100, convergence_threshold=1e-3, verbose=True)
        mmc_metric = mmc.fit(train_set_pca,train_label)
        features_pca = mmc_metric.transform(features_pca)
    
########################### test ########################    
for i in range (len(query_idx)):
    tmpgallery = gallery_idx.copy()
    label_q = labels[query_idx[i]]
    camId_q = camId[query_idx[i]]
    for j in range (len(gallery_idx)):
        if ((labels[gallery_idx[j]] == label_q) and (camId[gallery_idx[j]] == camId_q)):
            tmpgallery[j] = 0
    
    print ('query_idx = ',i,' classifing using knn under the transformed metric...')        
    results = KNN(query_idx[i], tmpgallery, K)
    for c in range (K):
        if (labels[int(results[c])] == label_q):
            accuracy_arr[i] = 1
accuracy = (np.count_nonzero(accuracy_arr))/len(accuracy_arr)    
print ("accuracy is ", accuracy)

#####################validation##########################
accuracy_arr_val = np.zeros(len(vali_query))
for i in range (len(vali_query)):
    classified = False
    tmpgallery = vali_gallery.copy()
    label_q = labels[vali_query[i]]
    camId_q = camId[vali_query[i]]
    for j in range (len(vali_gallery)):
        if ((labels[vali_gallery[j]] == label_q) and (camId[vali_gallery[j]] == camId_q)):
            tmpgallery[j] = 0
    
    print ('validation_query_idx = ',i,' classifing using knn under the transformed metric...')        
    results = KNN(vali_query[i], tmpgallery, K)
    for c in range (K):
        if (labels[int(results[c])] == label_q):
            accuracy_arr_val[i] = 1
accuracy = (np.count_nonzero(accuracy_arr_val))/len(accuracy_arr_val)
print ("validation accuracy is ", accuracy)















         