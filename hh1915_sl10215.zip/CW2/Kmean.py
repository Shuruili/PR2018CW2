from scipy.io import loadmat
from scipy.spatial import distance
from sklearn.cluster import KMeans
from timeit import default_timer as timer
from scipy import stats
import json
import numpy as np



def KNN(test_img, gallery,k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(gallery))
    idx_arr = np.zeros(len(gallery))
    results = np.zeros(k)
    for i in range(len(gallery)):
        if (gallery[i] != 0):
            pi = features_arr[gallery[i]]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent
        else:
            d_arr[i] = float('inf')

    tmparr = np.argsort(d_arr)
    
    for n in range (len(gallery)):
       idx_arr[n] = gallery[tmparr[n]] 
    
    for j in range (k):
        results[j] = idx_arr[j]
        
    return results


def KNN_KMean(test_img, center_features, center_classes, k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(center_features))
    idx_arr = np.zeros(len(center_features))
    result_classes = np.zeros(k)
    for i in range(len(center_features)):
            pi = center_features[i]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent

    tmparr = np.argsort(d_arr)
    
    for n in range (len(center_features)):
       idx_arr[n] = center_classes[tmparr[n]] 
    
    for j in range (k):
        result_classes[j] = idx_arr[j]
        
    return result_classes



######################################################################################################
K = 10 #RANK
starttime = timer()

file = loadmat('cuhk03_new_protocol_config_labeled.mat')
with open('feature_data.json', 'r') as f:
    features = json.load(f)
features_arr = np.array(features)
camId = file['camId'] 
filelist = file['filelist'] 
gallery_idx = file['gallery_idx']
labels = file['labels'] 
query_idx = file['query_idx'] 
train_idx = file['train_idx']    
results = np.zeros(K)
accuracy_arr = np.zeros(len(query_idx))
accuracy_Km_arr = np.zeros(len(query_idx))

gallery_idx = gallery_idx - 1;
query_idx = query_idx - 1;
train_idx = train_idx - 1;
camId = camId - 1;


##########################  K-Mean Clustering  ###########################################################
N_clusters = 700

km_gallery = np.zeros((len(gallery_idx),2048))
for n in range (len(gallery_idx)):
    km_gallery[n,:] = features_arr[gallery_idx[n]]
    
kmeans = KMeans(n_clusters=N_clusters, random_state=0).fit(km_gallery) 

cluster_center_classes = np.zeros(N_clusters)

for n in range (N_clusters):
    cluster_members_classes = np.zeros((1,1))
    for i in range (len(gallery_idx)):
        if (kmeans.labels_[i] == n):
            cluster_members_classes = np.append(cluster_members_classes,labels[gallery_idx[i]])
            #cluster_members_classes = np.delete(cluster_members_classes, 0, 0)  
    cluster_center_classes[n] = stats.mode(cluster_members_classes)[0]

for i in range (len(query_idx)):
    label_q = labels[query_idx[i]]
    result_classes = KNN_KMean(query_idx[i], kmeans.cluster_centers_, cluster_center_classes, K)
    for c in range (K):
        if (result_classes[c] == label_q):
            accuracy_Km_arr[i] = 1
    print ("query_idx=",i)
    
accuracy_Km = (np.count_nonzero(accuracy_Km_arr))/len(accuracy_Km_arr)    
print ("k-mean based knn accuracy is ", accuracy_Km)


endtime = timer()
print("time used is ", endtime-starttime)   




         