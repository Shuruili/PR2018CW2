from scipy.io import loadmat
from scipy.spatial import distance
from sklearn.cluster import KMeans
from timeit import default_timer as timer
from scipy import stats
from metric_learn import Covariance
from metric_learn import LMNN
from metric_learn import MMC_Supervised
from metric_learn import LSML


import json
import numpy as np



def KNN(test_img, gallery,k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(gallery))
    idx_arr = np.zeros(len(gallery))
    results = np.zeros(k)
    for i in range(len(gallery)):
        if (gallery[i] != 0):
            pi = features_arr[gallery[i]]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent
        else:
            d_arr[i] = float('inf')

    tmparr = np.argsort(d_arr)
    
    for n in range (len(gallery)):
       idx_arr[n] = gallery[tmparr[n]] 
    
    for j in range (k):
        results[j] = idx_arr[j]
        
    return results


def KNN_KMean(test_img, center_features, center_classes, k):
    pa = features_arr[test_img]
    d_arr = np.zeros(len(center_features))
    idx_arr = np.zeros(len(center_features))
    result_classes = np.zeros(k)
    for i in range(len(center_features)):
            pi = center_features[i]
            dcurrent = np.linalg.norm(pa-pi)
            d_arr[i] = dcurrent

    tmparr = np.argsort(d_arr)
    
    for n in range (len(center_features)):
       idx_arr[n] = center_classes[tmparr[n]] 
    
    for j in range (k):
        result_classes[j] = idx_arr[j]
        
    return result_classes



############################# read data  ##############################################
print ('Reading data...')

K = 1 #number of nearest neighbours
starttime = timer()
file = loadmat('cuhk03_new_protocol_config_labeled.mat')
with open('feature_data.json', 'r') as f:
    features = json.load(f)
features_arr = np.array(features)
camId = file['camId'] 
filelist = file['filelist'] 
gallery_idx = file['gallery_idx']
labels = file['labels'] 
query_idx = file['query_idx'] 
train_idx = file['train_idx']    
results = np.zeros(K)
accuracy_arr = np.zeros(len(query_idx))
accuracy_Km_arr = np.zeros(len(query_idx))

#converting index from 1-> to 0->
gallery_idx = gallery_idx - 1;
query_idx = query_idx - 1;
train_idx = train_idx - 1;
camId = camId - 1;


##########################  Mahalanobi distance learning:  ##################

train_set = np.zeros((len(train_idx),2048))
for i in range (len(train_idx)):
    train_set[i] = features_arr[train_idx[i]]
    
train_label = np.zeros((len(train_idx)))    
for i in range (len(train_idx)):
    train_label[i] = labels[train_idx[i]]

print ('Enter distance metric learning model type')        
    
model = input()
print ('training train set to obtain the distance matrix M...')    
if (model != 'base'):    
    if (model == 'cov'):
        cov = Covariance().fit(train_set)
        features_arr = cov.transform(features_arr)
                     
    if (model == 'lmnn'):
        lmnn = LMNN(k=5, max_iter=100, learn_rate=5e-9, use_pca=False)
        lmnn_metric = lmnn.fit(train_set,train_label)
        features_arr = lmnn_metric.transform(features_arr)

    if (model == 'MMC'):
        mmc = MMC_Supervised(max_iter=1000, convergence_threshold=1e-6)
        mmc_metric = mmc.fit(train_set,train_label)
        features_arr = mmc_metric.transform(features_arr)


for i in range (len(query_idx)):
    classified = False
    tmpgallery = gallery_idx.copy()
    label_q = labels[query_idx[i]]
    camId_q = camId[query_idx[i]]
    for j in range (len(gallery_idx)):
        if ((labels[gallery_idx[j]] == label_q) and (camId[gallery_idx[j]] == camId_q)):
            tmpgallery[j] = 0
    
    print ('query_idx = ',i,' classifing using knn under the transformed metric...')        
    results = KNN(query_idx[i], tmpgallery, K)
    for c in range (K):
        if (labels[int(results[c])] == label_q):
            accuracy_arr[i] = 1
accuracy = (np.count_nonzero(accuracy_arr))/len(accuracy_arr)    
print ("accuracy is ", accuracy)


















         